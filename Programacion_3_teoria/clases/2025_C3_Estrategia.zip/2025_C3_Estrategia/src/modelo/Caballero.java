package modelo;

public class Caballero extends Personaje
{
	protected int armadura;

	public Caballero(String nombre, Posicion posicion)
	{
		super(nombre, posicion, 800, 15, 5);
		this.armadura = 500;
	}

	

	@Override
	public void recibeDanio(int cantidad)
	{
		if (this.armadura >= cantidad)
			this.armadura -= cantidad;
		else
		{
			this.vitalidad -= (cantidad - this.armadura);
			this.armadura = 0;
		}

	}
	
	@Override
	public String toString()
	{
		return "Caballero "+super.toString()+ " armadura: "+this.armadura;
	}

}
