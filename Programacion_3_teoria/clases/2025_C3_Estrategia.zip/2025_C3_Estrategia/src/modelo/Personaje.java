package modelo;

public abstract class Personaje
{
	protected String nombre;
	protected Posicion posicion;
	protected int vitalidad;
	protected double alcance;
	protected int danio;

	public Personaje(String nombre, Posicion posicion, int vitalidad,int danio,double alcance)
	{
		super();
		this.nombre = nombre;
		this.posicion = posicion;
		this.vitalidad = vitalidad;
		this.danio=danio;
		this.alcance=alcance;
	}

	
	public void recibeDanio(int cantidad)
	{
		this.vitalidad -= cantidad;
	}

	
	public String atacar(Personaje otro)
	{
		String cartelito = this.nombre + " no pudo atacar a " + otro.nombre + " distancia muy grande";
		if (this.distancia(otro) <= this.alcance)
		{
			otro.recibeDanio(this.danio);
			cartelito = this.nombre + " ataco a " + otro.nombre;
		}
		return cartelito;
	}

	public String getNombre()
	{
		return nombre;
	}

	public int getVitalidad()
	{
		return vitalidad;
	}

	public double getX()
	{
		return this.posicion.getX();
	}

	public double getY()
	{
		return this.posicion.getY();
	}

	public void incrementaPosicion(double incX, double incY)
	{
		this.posicion.incrementaPosicion(incX, incY);
	}

	public double distancia(Personaje otro)
	{
		return this.posicion.distancia(otro.posicion);
	}

	@Override
	public String toString()
	{
		return "Nombre=" + nombre + ", posicion=" + posicion + ", vitalidad=" + vitalidad + "]";
	}
	
	
}
