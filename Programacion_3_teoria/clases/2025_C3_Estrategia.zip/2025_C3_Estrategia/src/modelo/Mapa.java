package modelo;

import java.util.ArrayList;
import java.util.Iterator;

public class Mapa
{
	private String nombre;
	private ArrayList<Personaje> personajes = new ArrayList<Personaje>();

	
	
	
	public Mapa(String nombre)
	{
		super();
		this.nombre = nombre;
	}

	@Override
	public String toString()
	{
		return "Mapa: " + nombre;
	}

	public String getDetalle()
	{
		StringBuilder sb = new StringBuilder();
		sb.append(this.toString());

		Iterator<Personaje> it = this.personajes.iterator();

		while (it.hasNext())
		{
			Personaje p = it.next();
			sb.append("\n");
			sb.append(p.toString());
		}

		return sb.toString();
	}

	public void agregarPersonaje(Personaje p)
	{
		this.personajes.add(p);
	}

	public void eliminarPersonaje(Personaje p)
	{
		this.personajes.remove(p);
	}

	public String getNombre()
	{
		return nombre;
	}

	public ArrayList<Personaje> getPersonajes()
	{
		return personajes;
	}

	void metodo(Personaje p1, Personaje p2)
	{
		p1.atacar(p2);
	}

	public void catastrofe()
	{
		for (int i = 0; i < this.personajes.size(); i++)
			this.personajes.get(i).recibeDanio(200);
	}

}
