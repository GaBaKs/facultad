package modelo;

public class Posicion
{
	private double x;
	private double y;

	public Posicion(double x, double y)
	{
		this.x = x;
		this.y = y;
	}

	public Posicion()
	{
		this(0, 0);
	}

	public double getX()
	{
		return x;
	}

	public double getY()
	{
		return y;
	}

	public void incrementaPosicion(double incX, double incY)
	{
		this.x += incX;
		this.y += incY;
	}

	public double distancia(Posicion otra)

	{
		double respuesta;
		double deltaX = this.x - otra.x;
		double deltaY = this.y - otra.y;
		respuesta = deltaX * deltaX + deltaY * deltaY;
		respuesta = Math.sqrt(respuesta);
		return respuesta;
	}

	@Override
	public String toString()
	{
		return "[ " + x + " ; " + y + " ]";
	}

	
	
}
