package modelo;

public class Arquero extends Personaje
{
	protected int cantidadFlechas;
	protected double alcanceFlechas;
	protected int danioFlecha;

	public Arquero(String nombre, Posicion posicion)
	{

		super(nombre, posicion, 400, 5, 5);
		this.cantidadFlechas = 20;
		this.alcanceFlechas = 100;
		this.danioFlecha = 20;
	}

	@Override
	public void recibeDanio(int cantidad)
	{
		this.vitalidad -= cantidad;
	}

	@Override
	public String atacar(Personaje otro)
	{
		String cartelito;
		if (this.cantidadFlechas > 0 && this.distancia(otro) <= this.alcanceFlechas)
		{
			otro.recibeDanio(danioFlecha);
			this.cantidadFlechas--;
			cartelito = this.nombre + " ataco con una flecha a " + otro.nombre;
		} else
		{
			cartelito = super.atacar(otro);
		}
		return cartelito;
	}

	@Override
	public String toString()
	{
		return "Arquero " + super.toString() + " Flechas: " + this.cantidadFlechas;
	}

	public void agregaFlechas(int cantidad)
	{
		this.cantidadFlechas += cantidad;
	}

}
