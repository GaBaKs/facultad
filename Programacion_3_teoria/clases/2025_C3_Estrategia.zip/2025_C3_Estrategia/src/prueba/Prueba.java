package prueba;

import modelo.Arquero;
import modelo.Caballero;
import modelo.Guerrero;
import modelo.Mapa;
import modelo.Personaje;
import modelo.Posicion;

public class Prueba
{

	public Prueba()
	{
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)
	{
		Mapa mapa=new Mapa("Bosque Oscuro");
		
		mapa.agregarPersonaje(new Guerrero("Aragorn", new Posicion(3, 4)));
		mapa.agregarPersonaje(new Arquero("Legolas", new Posicion()));
		mapa.agregarPersonaje(new Caballero("Jon Snow", new Posicion(30, 30)));
		
	
		System.out.println(mapa.getDetalle());
		
		Personaje g=mapa.getPersonajes().get(0);
		Personaje a=mapa.getPersonajes().get(1);
		Personaje c=mapa.getPersonajes().get(2);
		
		System.out.println(g.atacar(c));
		System.out.println(g.atacar(a));
		System.out.println(a.atacar(c));
		System.out.println(a.atacar(g));
		System.out.println(c.atacar(g));
		System.out.println(c.atacar(a));

		Arquero unArquero = (Arquero) a;
		unArquero.agregaFlechas(5);
		System.out.println(mapa.getDetalle());

	}

}
