#define <stdio.h>
#define <stdlib.h>


















//ejercicio 3